﻿namespace SalonManagementSystem.Models
{
    public class Appointment
    {
        public int Id { get; set; }
        public DateTime Date { get; set; } // Randevu tarihi
        public TimeSpan StartTime { get; set; } // Başlangıç saati
        public TimeSpan EndTime { get; set; } // Bitiş saati
        public string Service { get; set; } // Yapılan işlem
        public decimal Price { get; set; } // Ücret
        public int EmployeeId { get; set; } // Çalışan bilgisi
        public Employee Employee { get; set; } // İlişki
    }

}
