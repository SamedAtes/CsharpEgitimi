﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalonManagementSystem.Models;

public class AppointmentController : Controller
{
    private readonly ApplicationDbContext _context;

    public AppointmentController(ApplicationDbContext context)
    {
        _context = context;
    }

    // Randevu oluşturma sayfasına yönlendirme
    public IActionResult Create()
    {
        ViewData["Employees"] = _context.Employees.ToList(); // Çalışanları listele
        return View();
    }

    // Randevu oluşturma işlemi
    [HttpPost]
    public IActionResult Create(Appointment appointment)
    {
        if (ModelState.IsValid)
        {
            _context.Appointments.Add(appointment); // Yeni randevu ekle
            _context.SaveChanges();
            return RedirectToAction("Index", "Home"); // Ana sayfaya yönlendir
        }
        ViewData["Employees"] = _context.Employees.ToList(); // Çalışanları tekrar listele
        return View(appointment);
    }

    // Randevuları listeleme
    public IActionResult List()
    {
        var appointments = _context.Appointments.Include(a => a.Employee).ToList();
        return View(appointments); // Randevuları görüntüle
    }
}
