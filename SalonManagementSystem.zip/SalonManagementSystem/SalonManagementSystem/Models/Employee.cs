﻿namespace SalonManagementSystem.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; } // Çalışan adı
        public string Expertise { get; set; } // Uzmanlık alanı (örneğin: Saç Kesimi)
        public string WorkingHours { get; set; } // Müsaitlik saatleri
        public int SalonId { get; set; } // Hangi salonda çalışıyor?
        public Salon Salon { get; set; } // İlişki
    }

}
