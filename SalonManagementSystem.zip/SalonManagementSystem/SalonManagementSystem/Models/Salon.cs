﻿namespace SalonManagementSystem.Models
{
    public class Salon
    {
        public int Id { get; set; }
        public string Name { get; set; } // Salon adı
        public string WorkingHours { get; set; } // Çalışma saatleri
        public ICollection<Employee> Employees { get; set; } // Çalışanlar
    }

}
