using Microsoft.EntityFrameworkCore;
using SalonManagementSystem.Models;

var builder = WebApplication.CreateBuilder(args);

// Veritaban� ba�lant�s� ve DbContext ekleme
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Web uygulamas� i�in controller ve view ekleme
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Veritaban�na veriler eklemek i�in seed i�lemi
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

    // E�er veritaban�nda salonlar yoksa ekle
    if (!context.Salons.Any())
    {
        var salonA = new Salon { Name = "Salon A", WorkingHours = "09:00 - 18:00" };
        var salonB = new Salon { Name = "Salon B", WorkingHours = "10:00 - 19:00" };

        context.Salons.AddRange(salonA, salonB);
        context.SaveChanges();  // Salonlar� kaydet

        // Salonlara �al��anlar ekleyelim
        var employeeA1 = new Employee { Name = "Ahmet", WorkingHours = "09:00 - 18:00", SalonId = salonA.Id };
        var employeeA2 = new Employee { Name = "Mehmet", WorkingHours = "09:00 - 18:00", SalonId = salonA.Id };
        var employeeA3 = new Employee { Name = "Ay�e", WorkingHours = "09:00 - 18:00", SalonId = salonA.Id };

        var employeeB1 = new Employee { Name = "Fatma", WorkingHours = "10:00 - 19:00", SalonId = salonB.Id };
        var employeeB2 = new Employee { Name = "Zeynep", WorkingHours = "10:00 - 19:00", SalonId = salonB.Id };
        var employeeB3 = new Employee { Name = "Ali", WorkingHours = "10:00 - 19:00", SalonId = salonB.Id };

        context.Employees.AddRange(employeeA1, employeeA2, employeeA3, employeeB1, employeeB2, employeeB3);
        context.SaveChanges();  // �al��anlar� kaydet

        // �al��anlara uzmanl�k alanlar� ekleyelim
        context.Appointments.AddRange(
            new Appointment { Service = "Sa� Kesimi", Price = 100, EmployeeId = employeeA1.Id },
            new Appointment { Service = "Sa� Boyama", Price = 150, EmployeeId = employeeA1.Id },
            new Appointment { Service = "Sa� Kesimi", Price = 90, EmployeeId = employeeA2.Id },
            new Appointment { Service = "Sa� Boyama", Price = 140, EmployeeId = employeeA2.Id },
            new Appointment { Service = "Sa� Kesimi", Price = 110, EmployeeId = employeeA3.Id },
            new Appointment { Service = "Sa� Boyama", Price = 160, EmployeeId = employeeA3.Id },
            new Appointment { Service = "Sa� Kesimi", Price = 120, EmployeeId = employeeB1.Id },
            new Appointment { Service = "Sa� Boyama", Price = 170, EmployeeId = employeeB1.Id },
            new Appointment { Service = "Sa� Kesimi", Price = 115, EmployeeId = employeeB2.Id },
            new Appointment { Service = "Sa� Boyama", Price = 165, EmployeeId = employeeB2.Id },
            new Appointment { Service = "Sa� Kesimi", Price = 125, EmployeeId = employeeB3.Id },
            new Appointment { Service = "Sa� Boyama", Price = 175, EmployeeId = employeeB3.Id }
        );
        context.SaveChanges();  // Uzmanl�klar� kaydet
    }
}



app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();