﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SalonManagementSystem.Migrations
{
    public partial class AddAppointment : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
