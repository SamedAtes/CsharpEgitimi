﻿using Microsoft.AspNetCore.Mvc;
using SalonManagementSystem.Models;

[ApiController]
[Route("api/[controller]")]
public class EmployeeApiController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public EmployeeApiController(ApplicationDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult GetEmployees()
    {
        var employees = _context.Employees.ToList();
        return Ok(employees);
    }
}
