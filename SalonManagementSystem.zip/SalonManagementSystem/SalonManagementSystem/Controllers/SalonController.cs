﻿using Microsoft.AspNetCore.Mvc;
using SalonManagementSystem.Models;

public class SalonController : Controller
{
    private readonly ApplicationDbContext _context;

    public SalonController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var salons = _context.Salons.ToList(); // Tüm salonları getir
        return View(salons); // Veriyi View'a gönder
    }
}
