﻿using Microsoft.AspNetCore.Mvc;
using SalonManagementSystem.Models;

public class EmployeeController : Controller
{
    private readonly ApplicationDbContext _context;

    public EmployeeController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var employees = _context.Employees.ToList(); // Tüm çalışanları getir
        return View(employees); // Veriyi View'a gönder
    }
}
